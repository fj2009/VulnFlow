#!/usr/bin/env bash
# VulnFlow · Instalador: venv + dependencias.
# Hay que arrancar la BD antes: ./infra/levantar-db.sh start  (o exportar DATABASE_URL).
set -euo pipefail
cd "$(dirname "$0")"
PYTHON="${PYTHON:-python3}"
if [ ! -d .venv ]; then
  echo "[instalar] creando venv ($PYTHON)"
  "$PYTHON" -m venv .venv
fi
echo "[instalar] instalando dependencias…"
.venv/bin/pip install --upgrade pip >/dev/null
.venv/bin/pip install -r requirements.txt
echo "[instalar] listo. Arranca con: ./arrancar.sh start"