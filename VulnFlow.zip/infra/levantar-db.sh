#!/usr/bin/env bash
# VulnFlow · PostgreSQL 16 en Docker (puerto ANFITRIÓN 5434, no 5432).
# Uso: ./infra/levantar-db.sh start|stop|status
set -euo pipefail
DIR="$(cd "$(dirname "$0")" && pwd)"

# Fallo típico: la shell actual no lleva activado el grupo 'docker'
# (pero 'cardi' sí pertenece). Solución: envolver el comando en 'sg docker -c'.
run_docker() {
  if docker version >/dev/null 2>&1; then
    docker "$@"
  elif command -v sg >/dev/null 2>&1; then
    sg docker -c "docker $*"
  else
    echo "Acceso a Docker no disponible (usa 'sudo' o 'newgrp docker')." >&2
    exit 1
  fi
}

run_docker compose -f "$DIR/docker-compose.yml" "$@"