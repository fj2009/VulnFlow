#!/usr/bin/env python3
"""Seed de demo: activo local y un par de ejecuciones sin hallazgos todavía.

Uso: .venv/bin/python seed.py
Requisito: la API ha de haber inicializado la BD (o arrancar sin BD → SQLite).
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from sqlalchemy import select  # noqa: E402

from core.executor import ValidationError, execute  # noqa: E402
from core.models import Target  # noqa: E402
from core.session import init_db, session_scope  # noqa: E402


def main() -> int:
    init_db()
    with session_scope() as db:
        exists = db.scalar(select(Target).where(Target.ip == "127.0.0.1"))
        if exists:
            print(f"Ya existía target 127.0.0.1 (id {exists.id}).")
            return 0
        target = Target(ip="127.0.0.1", description="Target de demo local")
        db.add(target)
        db.commit()
        db.refresh(target)
        print(f"Target creado: id={target.id} 127.0.0.1")

        for slug in ("dig_dns", "curl_http"):
            try:
                run = execute(db, slug, {}, target, timeout=30)
                print(f"run #{run.id} [{run.tool_name}] → {run.status} ({run.duration:.1f}s)")
            except ValidationError as exc:
                print(f"  [skip] {slug}: {exc}")
            except Exception as exc:  # noqa: BLE001
                print(f"  [error] {slug}: {exc}")
    print("Demo lista. Abre http://127.0.0.1:8002/")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())