#!/usr/bin/env bash
# VulnFlow · Arranque/parada del agente FastAPI (puerto 8002).
# Uso: ./arrancar.sh start|stop|status|log
set -euo pipefail
cd "$(dirname "$0")"
HOST="${VULNFLOW_HOST:-127.0.0.1}"
PORT="${VULNFLOW_PORT:-8002}"
PIDFILE=".api.pid"
LOGFILE=".api.log"

if [ ! -x .venv/bin/uvicorn ]; then
  echo "Falta el venv. Ejecuta primero: ./instalar.sh" >&2
  exit 1
fi

case "${1:-}" in
  start)
    if [ -f "$PIDFILE" ] && kill -0 "$(cat "$PIDFILE")" 2>/dev/null; then
      echo "VulnFlow ya está en marcha (pid $(cat "$PIDFILE"))."; exit 0
    fi
    .venv/bin/uvicorn api.main:app --host "$HOST" --port "$PORT" >"$LOGFILE" 2>&1 &
    echo $! > "$PIDFILE"
    for _ in $(seq 1 20); do
      curl -sf "http://$HOST:$PORT/health" >/dev/null 2>&1 && break
      sleep 0.25
    done
    echo "VulnFlow en  http://$HOST:$PORT  (pid $(cat "$PIDFILE"))"
    ;;
  stop)
    if [ -f "$PIDFILE" ]; then
      kill "$(cat "$PIDFILE")" 2>/dev/null || true
      rm -f "$PIDFILE"
      echo "VulnFlow detenido."
    else
      echo "VulnFlow no estaba en marcha."
    fi
    ;;
  status)
    if [ -f "$PIDFILE" ] && kill -0 "$(cat "$PIDFILE")" 2>/dev/null; then
      echo "en marcha (pid $(cat "$PIDFILE")) — http://$HOST:$PORT"
    else
      echo "detenido"
    fi
    ;;
  log) tail -n 50 "$LOGFILE" ;;
  *) echo "uso: $0 start|stop|status|log" >&2; exit 1 ;;
esac