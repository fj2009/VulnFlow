# VulnFlow · AGENTS.md

Orquestador de pentesting: lanza herramientas del sistema contra un activo
autorizado, captura la salida completa, permite **marcar** un fragmento como
hallazgo y genera un reporte técnico Markdown (+ PDF) **firmado con Ed25519**.
Backend FastAPI + panel web propio offline (oscuro, Inter/JetBrains Mono vendidas);
BD PostgreSQL 16 en Docker (**puerto 5434**, no 5432) con **fallback a SQLite**.

Docs, comentarios y commits en **castellano** (convención del repo, como en el TFG).

## Comandos

- `./instalar.sh` → venv + dependencias. **Ojo:** usa `.venv/bin/pip`, no el pip del sistema (`--break-system-packages`).
- `./arrancar.sh start|stop|status|log` → uvicorn en `:8002` (pid `.api.pid`, log `.api.log`).
- `./infra/levantar-db.sh up|down|ps|logs` → Postgres 16 (user `vulnflow`/`vulnflow`, db `vulnflow`).
  En shells sin el grupo `docker` activo, el script reenvía solo a `sg docker -c` (no uses `sudo`:
  `cardi` no tiene acceso -vía grupo- directo desde sesiones viejas).
- `.venv/bin/python seed.py` → activo `127.0.0.1` + 2 ejecuciones de demo.
- `.venv/bin/python verify.py data/reports/report_*.md` → verifica firma Ed25519.
- Verificación rápida de python: `python3 -m py_compile core/*.py api/*.py`.

## Funcionamiento interno (el mapa mental)

- **`core/executor.py`** — catálogo `MODULES`: cada módulo = `Module(slug, tool, params[], builder)`.
  `builder` devuelve **argv (lista)**: nunca `shell=True`. Parámetros validados por esquema
  (`validate`). `execute()` crea `ToolRun` → `subprocess` con `start_new_session` + timeout que
  `killpg`; escribe la salida en `data/evidence/run_<id>/output.txt` (+`output.xml` si nmap).
  Los módulos **raw** (`msfconsole`) exigen `VULNFLOW_ALLOW_RAW=1`. Añadir una herramienta =
  definir builder + Module; nada más (la API/UI lo exponen solas).
- **`core/session.py`** — despues de `init_db()` el engine queda fijado (Postgres o SQLite).
  **Reiniciar el agente si cambia `DATABASE_URL`**: `get_engine()` cachea el engine en la
  primera llamada (en el arranque vía `lifespan`). Con BD caída `/q` no hay, pero `/health`
  reporta `db_up:false` y `storage` real.
- **Reporte** — `core/reporter.py`: contexto de BD → Jinja2 (`templates/report_template.md.j2`)
  → `data/reports/report_<alcance>_<ts>.md`. `sign_report()` **primero** incrusta el SHA-256 en
  el Markdown y **después** firma los bytes finales (el `.sig` cubre el contenido exacto guardado).
  `to_pdf()` usa `HTML(...).write_pdf` con CSS con `{}` → no usar `str.format` (usar `replace`).
- **Modelos** — `Target → ToolRun → Finding → Evidence`; encontrar el esqueleto en
  `core/models.py`. `Finding.cve_ids` es CSV de CVEs sugeridos (NVD).

## Gotchas

- **Puertos de este repo:** 5434 (BD) y 8002 (API) — distintos del TFG (5433/8001) para no chocar.
- **Cambios en `ui/`** requieren subir `?v=` en `ui/index.html` (cache-buster); la UI los pide por
  URL. Sin ese bump, el navegador sirve el JS/CSS viejos.
- Fuentes del panel **son copias** (SIL OFL) en `ui/static/fonts/`; no dependen de CDN.
- BD pensada para portabilidad: si le quitas el contenedor, la app sigue en SQLite
  (`data/vulnflow.db`) — perfectamente válido para demos; al volver `DATABASE_URL` a Postgres
  el engine se re-pinee al reiniciar.
- La severidad en BD es enum con mayúsculas (`LOW/MEDIUM/HIGH/CRITICAL`); el enum de Postgres es
  estricto (SQLite lo tolera) — normaliza siempre a `.upper()` antes de insertar.
- `scaner_red.py` (en `$HOME`, no relacionado) es un auditor nmap **root**: no lo confundas con
  el motor de VulnFlow, que corre sin privilegios y con timeout.

## Entorno (máquina actual)

- Kali 2026.3, Python 3.14; **todas** las herramientas del catálogo instaladas (nmap 7.99,
  gobuster, ffuf, dig, curl, msfconsole).
- Docker disponible con `sg docker -c "..."`; el script `levantar-db.sh` ya lo maneja.
- La BD demo `vulnflow-db` (contenedor) se deja **en marcha** tras el arranque inicial; parada:
  `./infra/levantar-db.sh down`.