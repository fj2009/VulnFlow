/* VulnFlow · panel web — vanilla JS. Marcado de hallazgos por selección nativa. */
"use strict";

const $ = (id) => document.getElementById(id);
const esc = (t) => String(t ?? "").replace(/[&<>"']/g,
  (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

async function api(path, opts = {}) {
  const res = await fetch(path, {
    headers: { "Content-Type": "application/json" },
    ...opts,
    body: opts.body ? JSON.stringify(opts.body) : undefined,
  });
  if (res.status === 204) return null;
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.detail || `${res.status} ${res.statusText}`);
  return data;
}

let TARGETS = [];
let TOOLS = [];
let toolsBySlug = {};

/* ---------------------------------------------------------------- nav */

document.querySelectorAll(".nav-item").forEach((btn) => {
  btn.addEventListener("click", () => switchView(btn.dataset.view));
});
function switchView(name) {
  document.querySelectorAll(".nav-item").forEach((b) => b.classList.toggle("active", b.dataset.view === name));
  document.querySelectorAll(".view").forEach((v) => v.classList.toggle("active", v.id === `view-${name}`));
}

/* ---------------------------------------------------------------- health */

async function refreshHealth() {
  try {
    const h = await api("/health");
    setLed("led-api", true);
    setLed("led-db", h.db_up === true);
    setLed("led-tools", Object.keys(h.tools).length > 0 && Object.values(h.tools).some(Boolean));
  } catch {
    setLed("led-api", false);
  }
}
function setLed(id, on) {
  const el = $(id);
  if (el) el.dataset.on = on ? "1" : "0";
}

/* ---------------------------------------------------------------- targets */

async function loadTargets() {
  const data = await api("/targets");
  TARGETS = data.targets;
  const tbody = $("targets-body");
  if (!TARGETS.length) {
    tbody.innerHTML = '<tr><td colspan="7" class="muted">Sin activos registrados.</td></tr>';
  } else {
    tbody.innerHTML = TARGETS.map((t) => `
      <tr>
        <td>${t.id}</td>
        <td><code>${esc(t.hostname || t.ip)}</code>${t.hostname && t.hostname !== t.ip ? ` <span class="muted">(${esc(t.ip)})</span>` : ""}</td>
        <td>${esc(t.os || "—")}</td>
        <td>${esc(t.description || "—")}</td>
        <td>${t.run_count}</td>
        <td>${t.findings_count}</td>
        <td><button class="btn ghost" onclick="delTarget(${t.id})">🗑</button></td>
      </tr>`).join("");
  }
  fillTargetSelects();
}
window.delTarget = async (id) => {
  if (!confirm(`¿Borrar el activo ${id} y todo su historial?`)) return;
  await api(`/targets/${id}`, { method: "DELETE" });
  loadTargets();
};
function fillTargetSelects() {
  const opts = TARGETS.map((t) => `<option value="${t.id}">${esc(t.hostname || t.ip)} (${esc(t.ip)})</option>`).join("");
  $("run-target").innerHTML = opts || '<option value="">Sin activos — registra uno primero</option>';
  $("rep-targets").innerHTML = '<option value="">Todos los activos</option>' + opts;
}

$("target-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const body = { ip: $("t-ip").value.trim(), hostname: $("t-host").value.trim() || null,
                 os: $("t-os").value.trim() || null, description: $("t-desc").value.trim() || null };
  await api("/targets", { method: "POST", body });
  e.target.reset();
  loadTargets();
});

/* ---------------------------------------------------------------- tools / exec */

async function loadTools() {
  const data = await api("/scans/tools");
  TOOLS = data.tools;
  toolsBySlug = Object.fromEntries(TOOLS.map((m) => [m.slug, m]));
  const sel = $("run-module");
  const groups = {};
  TOOLS.forEach((m) => (groups[m.category] ??= []).push(m));
  sel.innerHTML = Object.entries(groups).map(([cat, mods]) =>
    `<optgroup label="${esc(cat)}">${mods.map((m) =>
      `<option value="${m.slug}" ${m.available ? "" : "disabled"}>${esc(m.name)}${m.available ? "" : " (no instalada)"}</option>`).join("")}</optgroup>`
  ).join("");
  renderParams();
}
function renderParams() {
  const m = toolsBySlug[$("run-module").value];
  const box = $("params-box");
  if (!m) { box.innerHTML = ""; $("run-hint").textContent = ""; return; }
  box.innerHTML = `<div class="row">` + m.params.map((p) => `
    <label>${esc(p.label)}${p.required ? " *" : ""}
      <input data-param="${p.name}" value="${esc(p.default ?? "")}" placeholder="${esc(p.hint)}">
    </label>`).join("") + `</div>`;
  $("run-hint").textContent = `${m.description} ${m.raw ? "· ⚠ módulo raw" : ""}`;
  $("run-hint").className = "muted" + (m.raw ? " state-error" : "");
}
$("run-module").addEventListener("change", renderParams);

$("run-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const m = toolsBySlug[$("run-module").value];
  if (!m) return;
  if (!$("run-target").value) { alert("Registra un activo primero."); return; }
  const params = {};
  document.querySelectorAll("#params-box [data-param]").forEach((inp) => {
    if (inp.value !== "") params[inp.dataset.param] = inp.value;
  });
  const btn = $("run-btn");
  btn.disabled = true; btn.textContent = "⏳ Ejecutando…";
  try {
    const run = await api("/scans", { method: "POST", body: { target_id: +$("run-target").value, module_slug: m.slug, params } });
    openRun(run);
  } catch (err) { alert(err.message); }
  btn.disabled = false; btn.textContent = "▶ Ejecutar";
});

function openRun(run) {
  currentRun = run;
  $("run-meta").innerHTML = `activo <code>${esc(run.target)}</code> · estado <span class="state-${esc(run.status)}">${esc(run.status)}</span> · exit ${run.exit_code ?? "—"} · ${run.duration != null ? run.duration.toFixed(1) + " s" : "—"} · <code>${esc(run.command)}</code> · #${run.id}`;
  $("run-output").value = run.output || "";
  $("run-result").classList.remove("hidden");
  switchView("run");
}

let currentRun = null;

$("reset-run-btn").addEventListener("click", () => $("run-result").classList.add("hidden"));
$("mark-run-btn").addEventListener("click", () => {
  if (!currentRun) return;
  openMark(currentRun.id, currentRun.output || "");
});
$("mark-sel-btn").addEventListener("click", () => {
  if (!currentRun) return;
  const area = $("run-output");
  const start = area.selectionStart, end = area.selectionEnd;
  const sel = start === end ? "" : area.value.slice(start, end).trim();
  if (!sel) { $("mark-sel-msg").textContent = "Selecciona texto en la salida primero."; return; }
  openMark(currentRun.id, sel);
  $("mark-sel-msg").textContent = "";
});

/* ---------------------------------------------------------------- marking dialog */

function openMark(runId, evidence) {
  $("m-run").textContent = runId;
  $("m-evid").value = evidence;
  $("m-cves").checked = evidence.length < 200;
  $("cve-suggest").textContent = "";
  $("m-title").value = ""; $("m-desc").value = ""; $("m-remed").value = "";
  suggestCves(evidence);
  $("mark-dialog").showModal();
}

async function suggestCves(keyword) {
  const box = $("cve-suggest");
  if (!keyword || keyword.length < 4) { box.textContent = ""; return; }
  box.textContent = "Consultando NVD…";
  try {
    const data = await api("/findings/cves/suggest", { method: "POST", body: { keyword } });
    box.innerHTML = data.cves.length
      ? data.cves.map((c) => `<div><code>${esc(c.cve_id)}</code> · ${Math.round(c.base_score ?? 0)}/10 · ${esc(c.description.slice(0, 90))}…</div>`).join("")
      : "Sin CVEs para ese texto.";
  } catch (err) { box.textContent = "NVD no disponible (offline)."; }
}

$("mark-dialog").addEventListener("close", async () => {
  if (!$("mark-dialog").returnValue || $("mark-dialog").returnValue !== "ok") return;
  const body = {
    run_id: +$("m-run").textContent,
    severity: $("m-severity").value,
    title: $("m-title").value.trim(),
    description: $("m-desc").value.trim() || null,
    remediation: $("m-remed").value.trim() || null,
    evidence_text: $("m-evid").value.trim() || null,
    lookup_cves: $("m-cves").checked,
  };
  if (!body.title) { alert("El título es obligatorio."); return; }
  try {
    await api("/findings", { method: "POST", body });
    loadFindings(); loadTargets();
  } catch (err) { alert(err.message); }
});

/* ---------------------------------------------------------------- results */

async function loadRuns() {
  const data = await api("/scans");
  const body = $("runs-body");
  if (!data.runs.length) {
    body.innerHTML = '<tr><td colspan="8" class="muted">Sin ejecuciones todavía.</td></tr>';
    return;
  }
  body.innerHTML = data.runs.map((r) => `
    <tr onclick="viewRun(${r.id})" style="cursor:pointer">
      <td>${r.id}</td>
      <td><code>${esc(r.target)}</code></td>
      <td>${esc(r.tool_name)}</td>
      <td><code title="${esc(r.command)}">${esc(shortCmd(r.command))}</code></td>
      <td><span class="state-${esc(r.status)}">${esc(r.status)}</span></td>
      <td>${r.duration != null ? r.duration.toFixed(1) + " s" : "—"}</td>
      <td>${r.findings_count || ""}</td>
      <td><button class="btn ghost">Marcar</button></td>
    </tr>`).join("");
}
window.viewRun = async (id) => {
  try { openRun(await api(`/scans/${id}`)); } catch (err) { alert(err.message); }
};
function shortCmd(c) { return c.length > 64 ? c.slice(0, 64) + "…" : c; }

/* ---------------------------------------------------------------- findings */

async function loadFindings() {
  const data = await api("/findings");
  const body = $("findings-body");
  if (!data.findings.length) {
    body.innerHTML = '<tr><td colspan="6" class="muted">Sin hallazgos registrados.</td></tr>';
    return;
  }
  body.innerHTML = data.findings.map((f) => `
    <tr onclick="viewRun(${f.run_id})" style="cursor:pointer">
      <td>VF-${String(f.id).padStart(4, "0")}</td>
      <td><span class="badge ${esc(f.severity)}">${esc(f.severity)}</span></td>
      <td>${esc(f.title)}</td>
      <td><code>${esc(f.target || "—")}</code></td>
      <td><code>${esc(shortCmd(f.command || ""))}</code></td>
      <td>${(f.cves || []).map((c) => `<code>${esc(c)}</code>`).join(" ") || "—"}</td>
    </tr>`).join("");
}

/* ---------------------------------------------------------------- reports */

async function loadReports() {
  const data = await api("/reports");
  const body = $("reports-body");
  if (!data.reports.length) {
    body.innerHTML = '<tr><td colspan="4" class="muted">Sin reportes.</td></tr>';
    return;
  }
  body.innerHTML = data.reports.map((f) => `
    <tr>
      <td><code>${esc(f.name)}</code></td>
      <td>${esc(f.kind)}</td>
      <td>${f.size} B</td>
      <td class="row">
        <a class="btn ghost" href="/reports/${encodeURIComponent(f.name)}">↓</a>
        ${f.kind === ".md" ? `<button class="btn ghost" onclick="verifyReport('${esc(f.name)}')">✓ Verificar</button>` : ""}
      </td>
    </tr>`).join("");
}
window.verifyReport = async (name) => {
  try {
    const v = await api(`/reports/${encodeURIComponent(name)}/verify`);
    alert(v.ok ? `✓ FIRMA VÁLIDA\n${v.file}\nSHA-256: ${v.sha256_hex}` : `✗ Firma inválida: ${v.error}`);
  } catch (err) { alert(err.message); }
};

$("report-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const body = {
    target_ids: $("rep-targets").value ? [+$("rep-targets").value] : null,
    enrich_cves: $("rep-enrich").checked,
    sign: $("rep-sign").checked,
    pdf: $("rep-pdf").checked,
  };
  $("report-msg").textContent = "Generando…";
  try {
    const r = await api("/reports", { method: "POST", body });
    const box = $("report-result");
    box.classList.remove("hidden");
    box.innerHTML = `
      <h3>Reporte generado ✓</h3>
      <div class="meta">
        Markdown: <a href="/reports/${encodeURIComponent(r.md.name)}">${esc(r.md.name)}</a><br>
        ${r.pdf ? `PDF: <a href="/reports/${encodeURIComponent(r.pdf.name)}">${esc(r.pdf.name)}</a><br>` : "PDF: <span class='muted'>no generado (weasyprint ausente)</span><br>"}
        ${r.signature ? `Firma: <code>${esc(r.signature.sha256_hex)}</code><br><button class="btn ghost" onclick="verifyReport('${esc(r.md.name)}')">✓ Verificar firma</button>` : "Sin firma solicitada."}
      </div>`;
    loadReports();
  } catch (err) { alert(err.message); }
  $("report-msg").textContent = "";
});

/* ---------------------------------------------------------------- boot */

async function boot() {
  refreshHealth();
  setInterval(refreshHealth, 5000);
  try {
    await Promise.all([loadTargets(), loadTools(), loadRuns(), loadFindings(), loadReports()]);
  } catch (err) { console.error(err); }
}
document.addEventListener("DOMContentLoaded", boot);