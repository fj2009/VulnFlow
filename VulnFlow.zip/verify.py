#!/usr/bin/env python3
"""Verifica la firma Ed25519 de un reporte de VulnFlow.

Uso:
    .venv/bin/python verify.py data/reports/report_xxx.md

Copia los reportes a cualquier máquina y verifícalos con:
    [copia de la clave pública] → integridad + autenticidad del documento.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

from core.signer import verify_file


def main(argv: list[str]) -> int:
    if len(argv) != 2:
        print(__doc__)
        return 2
    path = Path(argv[1]).resolve()
    if not path.exists():
        print(f"✗ {argv[1]} no existe.")
        return 1
    result = verify_file(path)
    print(json.dumps(result, indent=2))
    if result.get("ok"):
        print("✓ Firma válida: el documento NO ha sido alterado desde la auditoría.")
        return 0
    print("✗ Firma inválida o ausente.")
    return 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))