"""Firma digital de reportes (bonus).

Se crea una clave Ed25519 local la primera vez (data/keys/signer_ed25519.key,
modo 0600). Al firmar un archivo se calcula su SHA-256, se firma y se escribe
el lado `*.sig` (base64) junto al original más un bloque de texto listo para
pegar en el reporte Markdown. `verify` comprueba integridad + autenticidad.
"""

from __future__ import annotations

import base64
import hashlib
import logging
from pathlib import Path

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
from cryptography.hazmat.primitives.serialization import load_pem_private_key

from .config import KEYS_DIR

log = logging.getLogger("vulnflow.signer")

PRIVATE_KEY_PATH = KEYS_DIR / "signer_ed25519.key"
PUBLIC_KEY_PATH = KEYS_DIR / "signer_ed25519.pub"


def _ensure_key() -> Ed25519PrivateKey:
    if PRIVATE_KEY_PATH.exists():
        raw = PRIVATE_KEY_PATH.read_bytes()
        return load_pem_private_key(raw, password=None)  # r.h.: Ed25519PrivateKey
    key = Ed25519PrivateKey.generate()
    PRIVATE_KEY_PATH.write_bytes(
        key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption(),
        )
    )
    PRIVATE_KEY_PATH.chmod(0o600)
    PUBLIC_KEY_PATH.write_bytes(_public_key_bytes(key.public_key()))
    log.info("Clave de firma Ed25519 creada en %s", PRIVATE_KEY_PATH)
    return key


def _public_key_bytes(pub: Ed25519PublicKey) -> bytes:
    return pub.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    )


def public_key() -> Ed25519PublicKey:
    return _ensure_key().public_key()


def public_key_text() -> str:
    return _public_key_bytes(public_key()).decode()


def sign_file(path: Path) -> dict:
    """Firma un fichero y escribe `<nombre>.sig` a su lado. Devuelve metadata."""
    if not path.exists():
        raise FileNotFoundError(path)
    data = path.read_bytes()
    digest = hashlib.sha256(data).digest()
    signature = _ensure_key().sign(data)
    sig_b64 = base64.b64encode(signature).decode()

    sig_path = path.with_suffix(path.suffix + ".sig")
    sig_path.write_text(
        f"SHA-256 (base64):    {base64.b64encode(digest).decode()}\n"
        f"SHA-256 (hex):       {digest.hex()}\n"
        f"Ed25519 signature:   {sig_b64}\n"
        f"Public key:          {_public_key_bytes(public_key()).decode().strip().replace(chr(10), ' ')}\n"
    )

    return {
        "file": path.name,
        "sig_file": sig_path.name,
        "sha256_hex": digest.hex(),
        "signature_b64": sig_b64,
        "pubkey": _public_key_bytes(public_key()).decode(),
    }


def sign_bytes(data: bytes) -> dict:
    """Firma bytes en memoria (sin tocar disco). Para pruebas y apéndices."""
    digest = hashlib.sha256(data).digest()
    signature = _ensure_key().sign(data)
    return {
        "sha256_hex": digest.hex(),
        "signature_b64": base64.b64encode(signature).decode(),
    }


def verify_file(path: Path) -> dict:
    """Verifica `<path>` contra su `<path>.sig`. Devuelve {ok, sha256_hex, ...}."""
    sig_path = path.with_suffix(path.suffix + ".sig")
    if not path.exists():
        return {"ok": False, "error": "no existe el fichero"}
    if not sig_path.exists():
        return {"ok": False, "error": "no existe el fichero .sig"}
    try:
        lines = sig_path.read_text().splitlines()
        sig_line = next(l for l in lines if l.startswith("Ed25519 signature:"))
        sig_b64 = sig_line.split(":", 1)[1].strip()
        signature = base64.b64decode(sig_b64)
        data = path.read_bytes()
        public_key().verify(signature, data)
        return {
            "ok": True,
            "file": path.name,
            "sha256_hex": hashlib.sha256(data).hexdigest(),
            "verified_with": "signer_ed25519.pub",
        }
    except Exception as exc:  # noqa: BLE001 — firma inválida o formato raro
        return {"ok": False, "error": str(exc)}