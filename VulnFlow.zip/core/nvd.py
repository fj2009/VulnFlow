"""Cliente de la NVD (National Vulnerability Database) para sugerir CVEs.

La integración es un bonus, NO un cuello de botella: si no hay internet o la
API no responde, se degrada a lista vacía sin romper el flujo del auditor.
"""

from __future__ import annotations

import time

import requests

NVD_ENDPOINT = "https://services.nvd.nist.gov/rest/json/cves/2.0"
_CACHE: dict[str, list[dict]] = {}
_LAST_CALL = 0.0
MIN_INTERVAL_SECONDS = 6.0  # cortesía del rate-limit público de NVD


def search_cves(
    keyword: str,
    limit: int = 5,
    timeout: float = 8.0,
) -> list[dict]:
    """Busca CVEs por palabras clave (producto/versión).

    Devuelve una lista de dicts con cve_id, description (EN), base_score y
    published, o [] ante cualquier fallo red/API.
    """
    global _LAST_CALL

    key = f"{keyword}:{limit}"
    if key in _CACHE:
        return _CACHE[key]

    # Rate-limit mínimo entre llamadas reales.
    wait = MIN_INTERVAL_SECONDS - (time.monotonic() - _LAST_CALL)
    if wait > 0:
        time.sleep(wait)

    try:
        resp = requests.get(
            NVD_ENDPOINT,
            params={"keywordSearch": keyword, "resultsPerPage": limit},
            headers={"User-Agent": "VulnFlow/1.0 (resp. auditoria)"},
            timeout=timeout,
        )
        resp.raise_for_status()
        data = resp.json().get("vulnerabilities", [])
    except Exception:  # noqa: BLE001 — offline o NVD caída: degradación limpia
        _CACHE[key] = []
        return []

    _LAST_CALL = time.monotonic()

    cves: list[dict] = []
    for item in data:
        cve = item.get("cve", {})
        desc_entries = cve.get("descriptions", [])
        desc = next(
            (d.get("value", "") for d in desc_entries if d.get("lang") == "en"),
            "",
        )
        metrics = cve.get("metrics", {}).get("cvssMetricV31") or cve.get(
            "metrics", {}
        ).get("cvssMetricV30") or []
        base_score = metrics[0]["cvssData"]["baseScore"] if metrics else None
        cves.append(
            {
                "cve_id": cve.get("id", ""),
                "description": desc,
                "base_score": base_score,
                "published": cve.get("published", ""),
            }
        )
    _CACHE[key] = cves
    return cves


def suggest_for_version(product: str, version: str, limit: int = 3) -> list[dict]:
    """Sugerencia cómoda: 'producto version' → lista de CVEs."""
    keyword = f"{product} {version}".strip()
    if len(keyword) < 4:
        return []
    return search_cves(keyword, limit=limit)