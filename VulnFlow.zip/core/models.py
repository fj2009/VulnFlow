"""Modelos SQLAlchemy 2.0 de VulnFlow.

Relación central (tal como la pide el diseño):

    Target 1───n ToolRun 1───n Finding 1───n Evidence

Un activo (ip/dominio) acumula múltiples ejecuciones; cada ejecución
(comando de una herramienta) puede producir varios hallazgos; cada hallazgo
guarda una o varias evidencias (texto, imágenes, ficheros).
"""

from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import DateTime, Enum, ForeignKey, Integer, String, Text
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


class Base(DeclarativeBase):
    pass


class Target(Base):
    __tablename__ = "targets"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    ip: Mapped[str] = mapped_column(String(64), index=True)
    hostname: Mapped[str | None] = mapped_column(String(255), nullable=True)
    os: Mapped[str | None] = mapped_column(String(64), nullable=True)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)

    runs: Mapped[list["ToolRun"]] = relationship(
        back_populates="target", cascade="all, delete-orphan"
    )

    @property
    def display(self) -> str:
        return self.hostname or self.ip


class ToolRun(Base):
    __tablename__ = "tool_runs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    target_id: Mapped[int] = mapped_column(ForeignKey("targets.id", ondelete="CASCADE"), index=True)
    tool_name: Mapped[str] = mapped_column(String(32))
    module_slug: Mapped[str] = mapped_column(String(48))
    command_executed: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(16), default="running")  # running|ok|timeout|error
    exit_code: Mapped[int | None] = mapped_column(Integer, nullable=True)
    output_file: Mapped[str | None] = mapped_column(String(255), nullable=True)
    output_xml: Mapped[str | None] = mapped_column(String(255), nullable=True)
    start_time: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)
    end_time: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    target: Mapped["Target"] = relationship(back_populates="runs")
    findings: Mapped[list["Finding"]] = relationship(
        back_populates="run", cascade="all, delete-orphan"
    )

    @property
    def duration(self) -> float | None:
        if self.end_time is None:
            return None
        return (self.end_time - self.start_time).total_seconds()


class Finding(Base):
    __tablename__ = "findings"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    run_id: Mapped[int] = mapped_column(ForeignKey("tool_runs.id", ondelete="CASCADE"), index=True)
    severity: Mapped[str] = mapped_column(Enum("LOW", "MEDIUM", "HIGH", "CRITICAL", name="severity"))
    title: Mapped[str] = mapped_column(String(255))
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    remediation: Mapped[str | None] = mapped_column(Text, nullable=True)
    cve_ids: Mapped[str | None] = mapped_column(String(255), nullable=True)  # CSV de CVEs sugeridos
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)

    run: Mapped["ToolRun"] = relationship(back_populates="findings")
    evidence: Mapped[list["Evidence"]] = relationship(
        back_populates="finding", cascade="all, delete-orphan"
    )

    @property
    def cve_list(self) -> list[str]:
        return [c.strip() for c in (self.cve_ids or "").split(",") if c.strip()]


class Evidence(Base):
    __tablename__ = "evidence"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    finding_id: Mapped[int] = mapped_column(ForeignKey("findings.id", ondelete="CASCADE"), index=True)
    type: Mapped[str] = mapped_column(String(16), default="text")  # text|image|file
    content_path: Mapped[str | None] = mapped_column(String(255), nullable=True)
    note: Mapped[str | None] = mapped_column(Text, nullable=True)
    timestamp: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)

    finding: Mapped["Finding"] = relationship(back_populates="evidence")