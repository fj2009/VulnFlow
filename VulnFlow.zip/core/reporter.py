"""Generador de reportes Markdown (Jinja2) con exportación PDF y firma.

El reporte se construye SIEMPRE sobre lo que hay en la BD en ese momento,
con el contexto completo: activos → ejecuciones → hallazgos → evidencias.
Cada hallazgo queda citado con su comando y su evidencia en crudo.
"""

from __future__ import annotations

import hashlib
import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path

from sqlalchemy import select
from sqlalchemy.orm import Session

from .config import EVIDENCE_DIR, REPORTS_DIR, TEMPLATES_DIR
from .executor import read_output
from .models import Finding, Target, ToolRun
from .parser import extract_version_hints, parse_nmap_xml
from .signer import public_key_text, sign_file

log = logging.getLogger("vulnflow.reporter")

MAX_OUTPUT_EXCERPT = 4000

_TEMPLATE_PATH = TEMPLATES_DIR / "report_template.md.j2"


@dataclass
class ReportOptions:
    target_ids: list[int] | None = None       # None = todos los activos
    enrich_cves: bool = False                 # consultar NVD por versiones detectadas
    filename: str | None = None


def _pub_short() -> str:
    pem = public_key_text()
    body = "\n".join(line for line in pem.splitlines() if "KEY" not in line)
    return body.strip()[:32] + "…"


def _evidence_text(finding: Finding) -> str:
    """Une el texto guardado de las evidencias del hallazgo (para el informe)."""
    parts = []
    for e in finding.evidence:
        if e.type == "text" and e.content_path:
            p = EVIDENCE_DIR / e.content_path
            if p.exists():
                try:
                    parts.append(p.read_text(errors="replace"))
                except OSError:
                    continue
        elif e.content_path:
            parts.append(f"[evidencia: {e.content_path}]")
    return "\n".join(parts)


def _build_context(db: Session, opts: ReportOptions, report_path: Path) -> dict:
    stmt = select(Target)
    if opts.target_ids:
        stmt = stmt.where(Target.id.in_(opts.target_ids))
    targets = list(db.scalars(stmt).all())

    context_targets = []
    summary = {"critical": 0, "high": 0, "medium": 0, "low": 0, "total": 0}
    cve_hints_cache: dict[tuple, list] = {}

    for target in targets:
        runs = sorted(target.runs, key=lambda r: r.start_time)
        t_out = {
            "display": target.display,
            "ip": target.ip,
            "hostname": target.hostname or "",
            "os": target.os or "",
            "description": target.description or "",
            "runs": [],
        }
        for run in runs:
            findings = sorted(run.findings, key=lambda f: f.id)
            f_out = []
            for finding in findings:
                evidence_text = _evidence_text(finding)
                f_out.append(
                    {
                        "ref": f"VF-{finding.id:04d}",
                        "severity": finding.severity,
                        "title": finding.title,
                        "description": finding.description or "",
                        "remediation": finding.remediation or "",
                        "cves": finding.cve_list,
                        "evidence_text": evidence_text,
                        "evidence_files": [
                            e.content_path for e in finding.evidence if e.content_path
                        ],
                    }
                )
                summary[finding.severity.lower()] += 1
                summary["total"] += 1

            excerpt = (read_output(run) or "")[:MAX_OUTPUT_EXCERPT]

            t_out["runs"].append(
                {
                    "id": run.id,
                    "tool_name": run.tool_name,
                    "module_slug": run.module_slug,
                    "command": run.command_executed,
                    "status": run.status,
                    "duration": run.duration,
                    "output_file": run.output_file or "",
                    "output_excerpt": excerpt,
                    "findings": f_out,
                }
            )

        # Enriquecimiento CVE: versiones detectadas → NVD (limitado).
        if opts.enrich_cves:
            for run in t_out["runs"]:
                if run["module_slug"] in ("nmap_ports", "nmap_services", "nmap_vuln"):
                    parsed = parse_nmap_xml(run["output_excerpt"].encode("utf-8", errors="replace"))
                    for hint in extract_version_hints(parsed[0] if parsed else {}):
                        key = (hint["product"], hint["version"])
                        if key in cve_hints_cache:
                            cves = cve_hints_cache[key]
                        else:
                            from .nvd import suggest_for_version

                            try:
                                cves = suggest_for_version(*key)
                            except Exception:  # noqa: BLE001 — degradación limpia
                                cves = []
                            cve_hints_cache[key] = cves
                        if cves:
                            summary.setdefault("cves", []).append({**hint, "cves": cves})

        context_targets.append(t_out)

    return {
        "report_date": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"),
        "environment": "Auditoría local · VulnFlow",
        "toolchain": "Python · FastAPI · PostgreSQL/SQLite · Jinja2",
        "signer_pub_short": _pub_short(),
        "summary": summary,
        "targets": context_targets,
        "cve_suggestions": summary.get("cves", []),
        "integrity": {"sha256": "", "file": report_path.name},
    }


def generate_report(db: Session, opts: ReportOptions | None = None) -> Path:
    opts = opts or ReportOptions()
    from jinja2 import Environment, FileSystemLoader, select_autoescape

    env = Environment(
        loader=FileSystemLoader(str(TEMPLATES_DIR)),
        autoescape=select_autoescape(default=False, enabled_extensions=()),
    )
    template = env.get_template("report_template.md.j2")

    prefix = "all"
    if opts.target_ids and len(opts.target_ids) == 1:
        prefix = f"target{opts.target_ids[0]}"
    ts = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    report_path = REPORTS_DIR / f"report_{prefix}_{ts}.md"

    ctx = _build_context(db, opts, report_path)
    markdown = template.render(ctx)
    report_path.write_text(markdown, encoding="utf-8")

    return report_path


def sign_report(report_path: Path) -> dict:
    """Firma el reporte y devuelve la metadata (para exponerla vía API).

    Orden correcto: primero se inserta el SHA-256 en el documento, después se
    firman los bytes FINALES del fichero (el .sig cubre el contenido exacto
    que queda guardado, incluida la línea de integridad).
    """
    text = report_path.read_text(encoding="utf-8")
    sha_of_final_before_embed = hashlib.sha256(text.encode("utf-8")).hexdigest()

    # La plantilla renderizó la línea con hash vacío (`- **SHA-256:** ``).
    embedded = text.replace("- **SHA-256:** ``", f"- **SHA-256:** `{sha_of_final_before_embed}`")
    # En algún futuro con otro template, fijamos el placeholder literal si quedase.
    embedded = embedded.replace("{{ integrity.sha256 }}", sha_of_final_before_embed)
    embedded = embedded.replace("{{ integrity.file }}", report_path.name)

    if embedded != text:
        report_path.write_text(embedded, encoding="utf-8")

    return sign_file(report_path)


def to_pdf(markdown_path: Path) -> Path | None:
    """Convierte el Markdown a PDF con WeasyPrint. None si no está disponible."""
    try:
        import markdown as md_lib
        from weasyprint import HTML
    except ImportError:
        log.warning("weasyprint/markdown no instalados — PDF omitido.")
        return None

    text = markdown_path.read_text(encoding="utf-8")
    html = md_lib.markdown(text, extensions=["tables", "fenced_code", "nl2br"])
    styled = (
        "<html><head><meta charset='utf-8'><style>"
        "body{font-family:'DejaVu Sans',sans-serif;max-width:820px;margin:40px auto;"
        "color:#0f172a;line-height:1.55}" 
        "h1,h2,h3{color:#0f172a}pre{background:#0f172a;color:#e2e8f0;padding:12px;"
        "border-radius:8px;overflow-x:auto;white-space:pre-wrap}code{font-family:monospace}"
        "table{border-collapse:collapse;width:100%}th,td{border:1px solid #cbd5e1;padding:6px 10px;"
        "text-align:left}blockquote{border-left:4px solid #334155;padding-left:12px;color:#475569}"
        "</style></head><body>__BODY__</body></html>"
    ).replace("__BODY__", html)

    pdf_path = markdown_path.with_suffix(".pdf")
    try:
        HTML(string=styled).write_pdf(str(pdf_path))
    except Exception as exc:  # noqa: BLE001 — weasyprint puede fallar por el sistema gráfico
        log.warning("Fallo de WeasyPrint: %s", exc)
        return None
    return pdf_path