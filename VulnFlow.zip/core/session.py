"""Sesión de base de datos con degradación elegante.

Estrategia:
1. Si `DATABASE_URL` apunta a un SQLite existente, úsalo tal cual.
2. Con DSN PostgreSQL: se prueba una conexión breve. Si responde → Postgres.
3. Si no responde → se cae a `data/vulnflow.db` (SQLite) y se avisa por log.

Así la API arranca aunque el contenedor de la BD esté parado, que es
exactamente el comportamiento que se pide para una herramienta de auditoría
portable (el modo de uso "con BD" y "sin BD" del TFG de referencia).
"""

from __future__ import annotations

import logging

from sqlalchemy import create_engine, text
from sqlalchemy.orm import Session, sessionmaker

from .config import DATABASE_URL, SQLITE_FALLBACK
from .models import Base

log = logging.getLogger("vulnflow.db")

_engine = None


def _make_postgres_engine(dsn: str):
    return create_engine(
        dsn,
        pool_pre_ping=True,
        pool_size=5,
        connect_args={"connect_timeout": 2},
    )


def _probe(engine) -> bool:
    try:
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        return True
    except Exception:  # noqa: BLE001 — cualquier fallo de conexión → degradación
        return False


def get_engine():
    """Devuelve el engine (creado una sola vez, con fallback a SQLite)."""
    global _engine
    if _engine is not None:
        return _engine

    if DATABASE_URL.startswith("sqlite"):
        url = DATABASE_URL if DATABASE_URL.startswith("sqlite:///") else f"sqlite:///{DATABASE_URL.removeprefix('sqlite://')}"
        _engine = create_engine(url)
        log.warning("Usando SQLite configurado explícitamente: %s", DATABASE_URL)
    elif _probe(_make_postgres_engine(DATABASE_URL)):
        _engine = _make_postgres_engine(DATABASE_URL)
        log.info("Conectado a PostgreSQL: %s", DATABASE_URL.split("@")[-1])
    else:
        sqlite_url = f"sqlite:///{SQLITE_FALLBACK}"
        _engine = create_engine(sqlite_url)
        log.warning("PostgreSQL NO disponible — degradado a SQLite: %s", SQLITE_FALLBACK)

    return _engine


def init_db() -> None:
    """Crea las tablas si no existen (idempotente)."""
    Base.metadata.create_all(get_engine())


def session_scope() -> Session:
    return sessionmaker(bind=get_engine(), expire_on_commit=False)()


def storage_mode() -> str:
    url = str(get_engine().url)
    return "sqlite" if url.startswith("sqlite") else "postgres"