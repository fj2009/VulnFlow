"""Motor de ejecución de VulnFlow.

No es un escáner: es un lanzador. Cada módulo del catálogo construye su
línea de argumentos (lista de argv, NUNCA una cadena a un shell), define qué
parámetros acepta y cómo validarlos. La ejecución queda registrada en
`tool_runs` y la salida completa se vuelca a `data/evidence/`.

Seguridad (nivel OSCP/OSCE):
- Sin `shell=True`: imposible inyección de comandos desde los parámetros.
- Validación estricta por esquema en cada módulo (IP/dominio, rangos, etc.).
- Los módulos `raw` (msfconsole) solo corren si `VULNFLOW_ALLOW_RAW=1`.
- Timeout estricto; el grupo de procesos se mata entero (no deja huérfanos).
"""

from __future__ import annotations

import ipaddress
import logging
import os
import re
import shlex
import shutil
import signal
import subprocess
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable

from sqlalchemy.orm import Session

from .config import ALLOW_RAW, DEFAULT_TIMEOUT, EVIDENCE_DIR
from .models import ToolRun

log = logging.getLogger("vulnflow.executor")


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)

HOSTNAME_RE = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9._-]{0,253}$")
WORDLIST_RE = re.compile(r"^[a-zA-Z0-9_./-]{1,255}\.txt$")


class ToolUnavailable(ValueError):
    """La herramienta no está instalada en el PATH."""


class ValidationError(ValueError):
    """Parámetros inválidos para el módulo."""


@dataclass
class Param:
    name: str
    label: str
    type: str = "str"          # str | int | bool | port_range
    required: bool = False
    default: object | None = None
    hint: str = ""
    validate: Callable[[str], str] | None = None


@dataclass
class Module:
    slug: str
    name: str
    tool: str
    category: str
    description: str
    params: list[Param] = field(default_factory=list)
    raw: bool = False
    builder: Callable[[dict, "Target"], list[str]] | None = None


def _opt(**kwargs):
    return Param(**kwargs)


# ---------------------------------------------------------------- validadores

def v_host(value: str) -> str:
    value = value.strip()
    try:
        ipaddress.ip_address(value)
        return value
    except ValueError:
        pass
    if HOSTNAME_RE.match(value):
        return value
    raise ValidationError(f"'{value}' no es una IP ni un dominio válido.")


def v_port_range(value: str) -> str:
    value = value.strip()
    if re.fullmatch(r"\d{1,5}(-\d{1,5})?(,\d{1,5}(-\d{1,5})?)*", value):
        return value
    raise ValidationError(f"'{value}' no es un rango de puertos válido (ej. 1-1000,80,443).")


def v_int(value: str) -> str:
    if not value.strip().isdigit():
        raise ValidationError(f"'{value}' debe ser un entero.")
    return value.strip()


def v_wordlist(value: str) -> str:
    if WORDLIST_RE.match(value.strip()):
        return value.strip()
    raise ValidationError(f"'{value}' no parece un wordlist .txt rutado (ej. /usr/share/wordlists/dirb/common.txt).")


def v_url(value: str) -> str:
    value = value.strip()
    if value.startswith(("http://", "https://")):
        return value
    raise ValidationError("Debe empezar por http:// o https://.")


# ---------------------------------------------------------------- builders

def _build_nmap(mode: str) -> Callable[[object, dict], list[str]]:
    def builder(t: "Target", params: dict) -> list[str]:
        argv = ["nmap", "-sT", "-Pn"]
        if mode in ("services", "vuln"):
            argv.append("-sV")
        if mode == "vuln":
            argv += ["--script", "vulners,vuln"]
        if params.get("ports"):
            argv += ["-p", params["ports"]]
        argv += ["-oX", "-"]
        argv.append(t.ip)
        return argv

    return builder


def _build_gobuster(t: "Target", params: dict) -> list[str]:
    url = params.get("url") or f"http://{t.ip}"
    argv = ["gobuster", "dir", "-u", url, "-w", params["wordlist"]]
    if params.get("status_codes"):
        argv += ["-s", params["status_codes"]]
    argv += ["--no-error", "-q"]
    return argv


def _build_ffuf(t: "Target", params: dict) -> list[str]:
    url = params.get("url") or f"http://{t.ip}/FUZZ"
    fuzz_url = url.replace("FUZZ", params.get("fuzz", "FUZZ"))
    argv = ["ffuf", "-u", f"{fuzz_url}", "-w", params["wordlist"], "-mc", params.get("match_codes", "200,204,301,302,307")]
    return argv


def _build_dig(t: "Target", params: dict) -> list[str]:
    argv = ["dig", t.ip, params.get("record", "A") or "A", "+noall", "+answer"]
    return argv


def _build_curl(t: "Target", params: dict) -> list[str]:
    url = params.get("url") or f"http://{t.ip}/"
    argv = ["curl", "-sS", "-i"]
    if params.get("timeout"):
        argv += ["--max-time", params["timeout"]]
    argv.append(url)
    return argv


def _build_msf(t: "Target", params: dict) -> list[str]:
    if not ALLOW_RAW:
        raise ValidationError(
            "Módulo 'raw' deshabilitado: exporta VULNFLOW_ALLOW_RAW=1 para ejecutar scripts de Metasploit."
        )
    script = params["script"].strip()
    if not script:
        raise ValidationError("El script de msfconsole está vacío.")
    return ["msfconsole", "-q", "-x", script]


# ---------------------------------------------------------------- catálogo

MODULES: list[Module] = [
    Module(
        slug="nmap_ports",
        name="Nmap · Escaneo de puertos",
        tool="nmap",
        category="reconocimiento",
        description="Escaneo TCP fiable (-sT, sin SYN, por compatibilidad con el agente).",
        builder=_build_nmap("ports"),
        params=[
            _opt(name="ports", label="Puertos", type="port_range", required=False, default="",
                 hint="ej. 1-1000,80,443 (vacío = top 1000)"),
        ],
    ),
    Module(
        slug="nmap_services",
        name="Nmap · Servicios y versiones",
        tool="nmap",
        category="reconocimiento",
        description="-sV para ver servicios, versiones y CPE (fuente para sugerir CVEs).",
        builder=_build_nmap("services"),
        params=[
            _opt(name="ports", label="Puertos", type="port_range", required=False, default=""),
        ],
    ),
    Module(
        slug="nmap_vuln",
        name="Nmap · Scripts de vulnerabilidades",
        tool="nmap",
        category="vulnerabilidad",
        description="--script vulners,vuln contra los puertos abiertos.",
        builder=_build_nmap("vuln"),
        params=[],
    ),
    Module(
        slug="gobuster_dir",
        name="Gobuster · Directorios",
        tool="gobuster",
        category="capa web",
        description="Fuerza bruta de directorios en la raíz del objetivo.",
        builder=_build_gobuster,
        params=[
            _opt(name="url", label="URL", type="str", required=False, default="",
                 hint="vacío = http://<target>/ ; puede incluir FUZZ"),
            _opt(name="wordlist", label="Wordlist", type="str", required=True,
                 default="/usr/share/wordlists/dirb/common.txt", validate=v_wordlist),
            _opt(name="status_codes", label="Códigos", type="str", required=False, default="200,204,301,302,307,403",
                 hint="códigos de estado a reportar"),
        ],
    ),
    Module(
        slug="ffuf_vhost",
        name="Ffuf · Fuzzing de contenidos",
        tool="ffuf",
        category="capa web",
        description="Fuzzing por diccionario; la URL debe contener la palabra FUZZ.",
        builder=_build_ffuf,
        params=[
            _opt(name="url", label="URL con FUZZ", type="str", required=True,
                 default="http://FUZZ.victima.test/"),
            _opt(name="wordlist", label="Wordlist", type="str", required=True,
                 default="/usr/share/wordlists/dirb/common.txt", validate=v_wordlist),
            _opt(name="match_codes", label="Códigos (mc)", type="str", required=False, default="200,204,301,302,307"),
        ],
    ),
    Module(
        slug="dig_dns",
        name="Dig · Resolución DNS",
        tool="dig",
        category="reconocimiento",
        description="Consulta DNS simple del registro indicado.",
        builder=_build_dig,
        params=[
            _opt(name="record", label="Registro", type="str", required=False, default="A",
                 hint="A | AAAA | MX | NS | TXT | CNAME"),
        ],
    ),
    Module(
        slug="curl_http",
        name="curl · Cabeceras HTTP",
        tool="curl",
        category="capa web",
        description="Recupera cabeceras y cuerpo de un endpoint.",
        builder=_build_curl,
        params=[
            _opt(name="url", label="URL", type="str", required=False, default="", validate=v_url),
            _opt(name="timeout", label="Max-time (s)", type="str", required=False, default="20", validate=v_int),
        ],
    ),
    Module(
        slug="msfconsole",
        name="Metasploit · Script -x (raw)",
        tool="msfconsole",
        category="explotación",
        description="Ejecuta un script msfconsole de una línea. REQUIERE VULNFLOW_ALLOW_RAW=1.",
        builder=_build_msf,
        params=[
            _opt(name="script", label="Script msfconsole (-x)", type="str", required=True,
                 hint='ej. use auxiliary/scanner/portscan/tcp; set RHOSTS <target>; run'),
        ],
        raw=True,
    ),
]

MODULES_BY_SLUG = {m.slug: m for m in MODULES}


def tool_exists(tool: str) -> bool:
    return shutil.which(tool) is not None


def module_public(module: Module) -> dict:
    """Vista no ejecutable del catálogo para la API/UI."""
    return {
        "slug": module.slug,
        "name": module.name,
        "tool": module.tool,
        "category": module.category,
        "description": module.description,
        "available": tool_exists(module.tool),
        "raw": module.raw,
        "params": [
            {
                "name": p.name,
                "label": p.label,
                "type": p.type,
                "required": p.required,
                "default": p.default,
                "hint": p.hint,
            }
            for p in module.params
        ],
    }


def _validate_params(module: Module, params: dict) -> dict:
    """Normaliza y valida los parámetros contra el esquema del módulo."""
    cleaned: dict = {}
    for param in module.params:
        key = param.name
        raw_value = params.get(key, param.default)
        if raw_value is None or raw_value == "":
            if param.required:
                raise ValidationError(f"Falta el parámetro obligatorio '{key}'.")
            cleaned[key] = param.default
            continue
        value = str(raw_value)
        if param.validate is not None:
            value = param.validate(value)
        cleaned[key] = value

    # Parámetros extra no permitidos: se ignoran (seguridad por diseño).
    return cleaned


def build_argv(module: Module, params: dict, target: "Target") -> list[str]:
    """Devuelve la lista de argv validada para el módulo (nunca una cadena shell)."""
    if module.raw:
        cleaned = {k: str(v) for k, v in params.items()}
        return module.builder(target, cleaned)
    return module.builder(target, _validate_params(module, params))


def _write_outputs(run_id: int, combined: bytes) -> tuple[str, str | None]:
    """Guarda la salida completa y (si produce XML) el XML por separado."""
    run_dir = EVIDENCE_DIR / f"run_{run_id}"
    run_dir.mkdir(parents=True, exist_ok=True)

    output_path = run_dir / "output.txt"
    output_path.write_bytes(combined)

    xml_path = None
    if b"<nmaprun" in combined[:4096]:
        xml_path = run_dir / "output.xml"
        xml_path.write_bytes(combined)

    return str(output_path.relative_to(EVIDENCE_DIR)), (
        str(xml_path.relative_to(EVIDENCE_DIR)) if xml_path else None
    )


def execute(
    db: Session,
    module_slug: str,
    params: dict | None,
    target: "Target",
    timeout: int = DEFAULT_TIMEOUT,
) -> ToolRun:
    """Ejecuta un módulo contra un target y registra tool_runs + evidencias.

    Devuelve la fila ToolRun ya persistida. Lanza ToolUnavailable si la
    herramienta no está en el PATH y ValidationError si falla la validación.
    """
    module = MODULES_BY_SLUG.get(module_slug)
    if module is None:
        raise ValidationError(f"Módulo desconocido: {module_slug}")

    if not tool_exists(module.tool):
        raise ToolUnavailable(f"La herramienta '{module.tool}' no está en el PATH.")

    argv = build_argv(module, params or {}, target)
    command = shlex.join(argv)

    run = ToolRun(target_id=target.id, tool_name=module.tool, module_slug=module.slug,
                  command_executed=command)
    db.add(run)
    db.commit()
    db.refresh(run)

    log.info("run %s: %s", run.id, command[:160])

    try:
        proc = subprocess.Popen(
            argv,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            stdin=subprocess.DEVNULL,
            start_new_session=True,  # grupo propio → kill en bloque
        )
        try:
            combined, _ = proc.communicate(timeout=timeout)
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid, signal.SIGTERM)
            try:
                combined, _ = proc.communicate(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid, signal.SIGKILL)
                combined, _ = proc.communicate()
            run.status = "timeout"
            run.exit_code = None
        else:
            run.status = "ok" if proc.returncode == 0 else "error"
            run.exit_code = proc.returncode
    except Exception as exc:  # noqa: BLE001 — fallo de arranque del proceso
        run.status = "error"
        run.exit_code = None
        db.commit()
        raise RuntimeError(f"No se pudo ejecutar '{module.tool}': {exc}") from exc

    run.output_file, run.output_xml = _write_outputs(run.id, combined or b"")
    run.end_time = _utcnow()
    db.commit()
    db.refresh(run)
    return run


def read_output(run: ToolRun) -> str:
    """Vuelve a leer la salida completa de una ejecución desde disco."""
    if not run.output_file:
        return ""
    path = EVIDENCE_DIR / run.output_file
    if not path.exists():
        return ""
    try:
        return path.read_text(errors="replace")
    except OSError:
        return ""