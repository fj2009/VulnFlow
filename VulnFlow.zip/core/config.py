"""Configuración central de VulnFlow.

Toda la configuración sale de variables de entorno con valores por defecto
sensatos para una herramienta local de auditoría. Nunca se recogen aquí rutas
ni credenciales por código duro fuera de los valores de desarrollo.
"""

from __future__ import annotations

import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

DATA_DIR = BASE_DIR / "data"
EVIDENCE_DIR = DATA_DIR / "evidence"
REPORTS_DIR = DATA_DIR / "reports"
KEYS_DIR = DATA_DIR / "keys"
TEMPLATES_DIR = BASE_DIR / "templates"

for _d in (DATA_DIR, EVIDENCE_DIR, REPORTS_DIR, KEYS_DIR):
    _d.mkdir(parents=True, exist_ok=True)

# DSN por defecto: PostgreSQL local de VulnFlow (no coincide con el 5433 del TFG).
DATABASE_URL = os.environ.get(
    "DATABASE_URL",
    "postgresql+psycopg://vulnflow:vulnflow@127.0.0.1:5434/vulnflow",
)

# Si PostgreSQL no responde, se cae a este fichero SQLite (portabilidad cero-fricción).
SQLITE_FALLBACK = DATA_DIR / "vulnflow.db"

HOST = os.environ.get("VULNFLOW_HOST", "127.0.0.1")
PORT = int(os.environ.get("VULNFLOW_PORT", "8002"))

# Tiempo máximo por ejecución de herramienta (segundos).
DEFAULT_TIMEOUT = int(os.environ.get("VULNFLOW_TIMEOUT", "300"))

# Los módulos 'raw' (msfconsole) solo se ejecutan con esta marca a 1.
ALLOW_RAW = os.environ.get("VULNFLOW_ALLOW_RAW", "0") == "1"

# Concisa a propósito: para ver todo, exporta VULNFLOW_DEBUG=1.
def dump() -> dict[str, str]:
    return {
        "BASE_DIR": str(BASE_DIR),
        "DATABASE_URL": _hide_password(DATABASE_URL),
        "sqlite_fallback": str(SQLITE_FALLBACK),
        "port": str(PORT),
        "allow_raw": str(ALLOW_RAW),
    }


def _hide_password(dsn: str) -> str:
    if "://" not in dsn or "@" not in dsn:
        return dsn
    scheme, _, rest = dsn.partition("://")
    userinfo, _, host = rest.rpartition("@")
    if ":" in userinfo:
        userinfo = userinfo.split(":", 1)[0] + ":****"
    return f"{scheme}://{userinfo}@{host}"