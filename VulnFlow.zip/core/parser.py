"""Parsers para limpiar la salida de las herramientas y extraer datos útiles.

El objetivo no es reescribir un escáner: es convertir salida cruda en
estructuras JSON-serializables que la UI pueda mostrar y el reportero pueda
citar como evidencia estructurada.
"""

from __future__ import annotations

import re
import xml.etree.ElementTree as ET

PORT_LINE_RE = re.compile(
    r"^\d+/(tcp|udp)\s+(open|closed|filtered)\s+(\S+)\s*(.*)$", re.MULTILINE
)


def parse_nmap_xml(raw: str | bytes) -> list[dict]:
    """Parseo defensivo del XML de nmap (-oX).

    Devuelve: [{ip, hostname, os, ports: [{port, proto, state, service, product,
    version, cpe}]}]. Nunca lanza: cualquier error devuelve lista vacía.
    """
    try:
        if isinstance(raw, bytes):
            raw = raw.decode("utf-8", errors="replace")
        root = ET.fromstring(raw)
    except ET.ParseError:
        return []

    targets: list[dict] = []
    for host in root.findall("host"):
        addr_el = host.find("address")
        if addr_el is None:
            continue
        ip = addr_el.get("addr", "")
        hostnames = [
            h.get("name")
            for h in host.findall("hostnames/hostname")
            if h.get("name")
        ]
        os_name = ""
        osmatch = host.find(".//osmatch")
        if osmatch is not None:
            os_name = osmatch.get("name", "").split(" (")[0]

        ports: list[dict] = []
        for port in host.findall(".//port"):
            state_el = port.find("state")
            if state_el is None or state_el.get("state") != "open":
                continue
            service_el = port.find("service")
            product = version = cpe = ""
            if service_el is not None:
                product = service_el.get("product", "")
                version = service_el.get("version", "")
                cpe_el = service_el.find("cpe")
                if cpe_el is not None:
                    cpe = cpe_el.text or ""
            ports.append(
                {
                    "port": port.get("portid", ""),
                    "proto": port.get("protocol", "tcp"),
                    "state": "open",
                    "service": service_el.get("name", "") if service_el is not None else "",
                    "product": product,
                    "version": version,
                    "cpe": cpe,
                }
            )

        targets.append(
            {
                "ip": ip,
                "hostname": hostnames[0] if hostnames else "",
                "os": os_name,
                "ports": ports,
            }
        )
    return targets


def parse_open_ports_from_text(raw: str) -> list[int]:
    """Fallback barato: extrae puertos 'open' de una salida de texto estilo nmap."""
    found: list[int] = []
    for m in PORT_LINE_RE.finditer(raw or ""):
        if m.group(2) == "open":
            port = int(m.group(1).split("/")[0])
            if port not in found:
                found.append(port)
    return sorted(found)


def extract_version_hints(target: dict) -> list[dict]:
    """De un target parseado, devuelve (producto, versión) para sugerir CVEs.

    Solo se conservan entradas con producto y versión, que son las que un
    lookup NVD puede aprovechar.
    """
    hints = []
    for port in target.get("ports", []):
        if port.get("product") and port.get("version"):
            hints.append(
                {
                    "service": port["service"],
                    "port": port["port"],
                    "product": port["product"],
                    "version": port["version"],
                }
            )
    return hints