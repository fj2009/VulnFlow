"""Rutas de reportes: generación Markdown + PDF, firma y verificación."""

from __future__ import annotations

from fastapi import APIRouter, Depends
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from core.config import REPORTS_DIR
from core.reporter import ReportOptions, generate_report, sign_report, to_pdf
from core.signer import verify_file
from .deps import get_db

router = APIRouter(prefix="/reports", tags=["reports"])

REPO_RGX = r"^[a-zA-Z0-9_\-./]+\.(md|pdf|sig)$"


def _safe_path(filename: str):
    """Evita traversal fuera de data/reports/ (solo nombre de archivo plano)."""
    if "/" in filename or "\\" in filename or not filename.endswith((".md", ".pdf", ".sig")):
        raise ValueError("Nombre de fichero no válido.")
    return REPORTS_DIR / filename


class ReportIn(BaseModel):
    target_ids: list[int] | None = None
    enrich_cves: bool = False
    sign: bool = True
    pdf: bool = True


@router.post("", status_code=201)
def create_report(body: ReportIn, db: Session = Depends(get_db)):
    opts = ReportOptions(target_ids=body.target_ids, enrich_cves=body.enrich_cves)
    path = generate_report(db, opts)

    result: dict = {
        "md": {"name": path.name, "path": str(path)},
        "pdf": None,
        "signature": None,
        "nvd_enrichment": body.enrich_cves,
    }
    if body.pdf:
        pdf = to_pdf(path)
        result["pdf"] = {"name": pdf.name, "path": str(pdf)} if pdf else None
    if body.sign:
        result["signature"] = sign_report(path)
    return result


@router.get("")
def list_reports():
    files = sorted(REPORTS_DIR.iterdir(), key=lambda p: p.stat().st_mtime, reverse=True)
    return {
        "reports": [
            {
                "name": p.name,
                "size": p.stat().st_size,
                "kind": p.suffix,
            }
            for p in files
            if p.is_file()
        ]
    }


@router.get("/{filename}")
def download_report(filename: str):
    path = _safe_path(filename)
    if not path.exists():
        raise ValueError(f"{filename} no existe.")
    return FileResponse(path, filename=filename)


@router.get("/{filename}/verify")
def verify_report(filename: str):
    path = _safe_path(filename)
    if not path.exists():
        raise ValueError(f"{filename} no existe.")
    return verify_file(path)