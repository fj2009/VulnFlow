"""Dependencias compartidas por las rutas: sesión de BD y excepciones."""

from __future__ import annotations

import logging

from fastapi import HTTPException
from sqlalchemy.orm import Session

from core.executor import ToolUnavailable, ValidationError
from core.session import session_scope

log = logging.getLogger("vulnflow.api")


def get_db():
    db = session_scope()
    try:
        yield db
    except (ValidationError, ToolUnavailable) as exc:
        db.rollback()
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception:  # noqa: BLE001
        db.rollback()
        raise
    finally:
        db.close()


def http_400(detail: str) -> HTTPException:
    return HTTPException(status_code=400, detail=detail)


def http_404(detail: str) -> HTTPException:
    return HTTPException(status_code=404, detail=detail)


def find_or_404(db: Session, model, obj_id: int):
    obj = db.get(model, obj_id)
    if obj is None:
        raise http_404(f"{model.__name__} {obj_id} no existe.")
    return obj