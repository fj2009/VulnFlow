"""Rutas de ejecución de herramientas: catálogo y lanzamiento."""

from __future__ import annotations

from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session

from core.executor import MODULES, execute, module_public, read_output
from core.models import Target, ToolRun
from .deps import find_or_404, get_db

router = APIRouter(prefix="/scans", tags=["scans"])


class RunIn(BaseModel):
    target_id: int
    module_slug: str
    params: dict = {}


def run_payload(run: ToolRun) -> dict:
    return {
        "id": run.id,
        "target_id": run.target_id,
        "target": run.target.display,
        "tool_name": run.tool_name,
        "module_slug": run.module_slug,
        "command": run.command_executed,
        "status": run.status,
        "exit_code": run.exit_code,
        "start_time": run.start_time.isoformat(),
        "end_time": run.end_time.isoformat() if run.end_time else None,
        "duration": run.duration,
        "findings_count": len(run.findings),
        "output_file": run.output_file,
    }


@router.get("/tools")
def list_tools():
    """Catálogo de módulos con su disponibilidad real en el PATH."""
    return {"tools": [module_public(m) for m in MODULES]}


@router.post("", status_code=201)
def run_tool(body: RunIn, db: Session = Depends(get_db)):
    target = find_or_404(db, Target, body.target_id)
    run = execute(db, body.module_slug, body.params or {}, target)
    return {**run_payload(run), "output": read_output(run)}


@router.get("")
def list_runs(db: Session = Depends(get_db)):
    runs = db.scalars(select(ToolRun).order_by(ToolRun.id.desc()).limit(100)).all()
    return {"runs": [run_payload(r) for r in runs]}


@router.get("/{run_id}")
def get_run(run_id: int, db: Session = Depends(get_db)):
    run = find_or_404(db, ToolRun, run_id)
    return {
        **run_payload(run),
        "output": read_output(run),
        "findings": [
            {
                "id": f.id,
                "severity": f.severity,
                "title": f.title,
                "cves": f.cve_list,
            }
            for f in sorted(run.findings, key=lambda f: f.id)
        ],
    }