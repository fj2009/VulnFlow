"""Rutas de activos (targets): registro, listado y borrado."""

from __future__ import annotations

from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from core.executor import v_host
from core.models import Target
from .deps import find_or_404, get_db

router = APIRouter(prefix="/targets", tags=["targets"])


class TargetIn(BaseModel):
    ip: str = Field(..., examples=["10.10.10.5", "scanme.nmap.org"])
    hostname: str | None = None
    os: str | None = None
    description: str | None = None


def target_payload(t: Target, db: Session) -> dict:
    return {
        "id": t.id,
        "ip": t.ip,
        "hostname": t.hostname,
        "os": t.os,
        "description": t.description,
        "created_at": t.created_at.isoformat(),
        "run_count": len(t.runs),
        "findings_count": sum(len(r.findings) for r in t.runs),
    }


@router.get("")
def list_targets(db: Session = Depends(get_db)):
    targets = db.scalars(select(Target).order_by(Target.id)).all()
    return {"targets": [target_payload(t, db) for t in targets]}


@router.post("", status_code=201)
def create_target(body: TargetIn, db: Session = Depends(get_db)):
    if not body.ip:
        raise ValueError("El activo necesita una IP o dominio.")
    v_host(body.ip)  # lanza ValidationError → 400 vía dependencia
    target = Target(
        ip=body.ip,
        hostname=body.hostname or None,
        os=body.os or None,
        description=body.description or None,
    )
    db.add(target)
    db.commit()
    db.refresh(target)
    return target_payload(target, db)


@router.get("/{target_id}")
def get_target(target_id: int, db: Session = Depends(get_db)):
    return target_payload(find_or_404(db, Target, target_id), db)


@router.delete("/{target_id}", status_code=204)
def delete_target(target_id: int, db: Session = Depends(get_db)):
    target = find_or_404(db, Target, target_id)
    db.delete(target)
    db.commit()