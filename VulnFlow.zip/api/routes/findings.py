"""Rutas de hallazgos — el «marcado» que alimenta el reporte.

Al llegar un hallazgo se guarda la evidencia (texto marcado por el auditor)
en disco y se vincula a la ejecución que la produjo. Opcionalmente el agente
sugiere CVEs de la NVD a partir del texto/versión marcada.
"""

from __future__ import annotations

from datetime import datetime, timezone

from fastapi import APIRouter, Body, Depends
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from core.config import EVIDENCE_DIR
from core.models import Evidence, Finding, ToolRun
from core.nvd import search_cves
from .deps import find_or_404, get_db

router = APIRouter(prefix="/findings", tags=["findings"])

SEVERITIES = ("LOW", "MEDIUM", "HIGH", "CRITICAL")


class FindingIn(BaseModel):
    run_id: int
    severity: str = Field(..., examples=["HIGH"])
    title: str
    description: str | None = None
    remediation: str | None = None
    evidence_text: str | None = None
    note: str | None = None
    lookup_cves: bool = False


def finding_payload(f: Finding) -> dict:
    return {
        "id": f.id,
        "run_id": f.run_id,
        "severity": f.severity,
        "title": f.title,
        "description": f.description,
        "remediation": f.remediation,
        "cves": f.cve_list,
        "created_at": f.created_at.isoformat(),
        "evidence": [
            {
                "id": e.id,
                "type": e.type,
                "content_path": e.content_path,
                "note": e.note,
            }
            for e in f.evidence
        ],
    }


def _write_evidence(finding_id: int, text: str) -> str:
    """Persiste el texto marcado y devuelve la ruta relativa a data/evidence/."""
    fname = f"finding_{finding_id}.txt"
    (EVIDENCE_DIR / fname).write_text(text, encoding="utf-8")
    return fname


@router.post("", status_code=201)
def create_finding(
    body: FindingIn = Body(...),
    db: Session = Depends(get_db),
):
    if body.severity.upper() not in SEVERITIES:
        raise ValueError(f"Severidad inválida: {body.severity}")
    if not body.title.strip():
        raise ValueError("El hallazgo necesita un título.")

    finding = Finding(
        run_id=body.run_id,
        severity=body.severity.upper(),
        title=body.title.strip(),
        description=body.description or None,
        remediation=body.remediation or None,
    )
    find_or_404(db, ToolRun, body.run_id)
    db.add(finding)
    db.flush()

    if body.evidence_text:
        rel_path = _write_evidence(finding.id, body.evidence_text)
        evidence = Evidence(
            finding_id=finding.id,
            type="text",
            content_path=rel_path,
            note=body.note or "Evidencia marcada por el auditor",
        )
        db.add(evidence)

    if body.lookup_cves:
        finding.cve_ids = _suggest_cves(body.evidence_text or body.title)

    db.commit()
    db.refresh(finding)
    return finding_payload(finding)


def _suggest_cves(keyword: str, limit: int = 3) -> str | None:
    keyword = " ".join(keyword.split())[:200]
    if len(keyword) < 4:
        return None
    cves = search_cves(keyword, limit=limit)
    return ",".join(c["cve_id"] for c in cves) if cves else None


@router.get("")
def list_findings(db: Session = Depends(get_db)):
    rows = db.scalars(
        select(Finding, ToolRun)
        .join(ToolRun, Finding.run_id == ToolRun.id)
        .order_by(Finding.id.desc())
    ).all()
    return {
        "findings": [
            {
                **finding_payload(f),
                "target": r.target.display if r.target else None,
                "command": r.command_executed,
                "tool_name": r.tool_name,
            }
            for f, r in rows
        ]
    }


@router.post("/cves/suggest")
def suggest_cves(db: Session = Depends(get_db), keyword: str = Body(..., embed=True)):
    return {"cves": search_cves(keyword)}