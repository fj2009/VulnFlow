"""VulnFlow · API FastAPI + panel web adjunto.

Arranque:  .venv/bin/uvicorn api.main:app --port 8002
Web:       http://127.0.0.1:8002/
"""

from __future__ import annotations

import logging
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from core.config import BASE_DIR, dump
from core.session import init_db, storage_mode
from api.routes import findings, reports, scans, targets

logging.basicConfig(
    level=logging.INFO,
    format="%(levelname)s %(name)s: %(message)s",
)

UI_DIR = BASE_DIR / "ui"
GRAPHIC_ASSETS_RE = r"\.(css|js|woff2|png|jpg|svg)$"


@asynccontextmanager
async def lifespan(_: FastAPI):
    init_db()
    logging.getLogger("vulnflow").info("VulnFlow arrancado (%s / %s)", storage_mode(), dump()["port"])
    yield


app = FastAPI(title="VulnFlow", version="1.0.0", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[f"http://127.0.0.1:{dump()['port']}", "http://localhost:8002"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(targets.router)
app.include_router(scans.router)
app.include_router(findings.router)
app.include_router(reports.router)

app.mount("/static", StaticFiles(directory=UI_DIR / "static"), name="static")


@app.get("/health")
def health():
    from core.session import get_engine
    from sqlalchemy import text

    db_up = False
    try:
        with get_engine().connect() as conn:
            conn.execute(text("SELECT 1"))
        db_up = True
    except Exception:  # noqa: BLE001
        db_up = False

    from core.executor import MODULES

    return {
        "status": "ok",
        "storage": storage_mode(),
        "db_up": db_up,
        "tools": {m.tool: _tool_available(m.tool) for m in MODULES},
    }


def _tool_available(tool: str) -> bool:
    from core.executor import tool_exists

    return tool_exists(tool)


@app.get("/", include_in_schema=False)
def index():
    return FileResponse(UI_DIR / "index.html")


@app.get("/favicon.ico", include_in_schema=False)
def favicon():
    return FileResponse(UI_DIR / "static" / "favicon.svg", media_type="image/svg+xml")